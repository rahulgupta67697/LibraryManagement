import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './BookDetails.css';

export default function BookDetail() {
  const { id } = useParams();
  const books = useSelector((state) => state.books.books); // ✅ Get books from Redux

  const book = books.find((b) => String(b.id) === String(id)); // Ensure type match

  if (!book) {
    return (
      <div className="book-detail-container">
        <h1 className="book-detail-title">Book Not Found</h1>
        <Link to="/browse" className="back-link">Back to Browse</Link>
      </div>
    );
  }

  return (
    <div className="book-detail-container">
      <h1 className="book-detail-title">{book.title}</h1>
      <p className="book-detail-info"><strong>Author:</strong> {book.author}</p>
      <p className="book-detail-info"><strong>Description:</strong> {book.description}</p>
      <p className="book-detail-info"><strong>Rating:</strong> {book.rating}</p>
      <p className="book-detail-info"><strong>Category:</strong> {book.category}</p>
      <Link to="/browse" className="back-link">Back to Browse</Link>
    </div>
  );
}
