import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './BrowseBooks.css';

export default function BrowseBooks() {
  const { category } = useParams();
const books = useSelector((state) => state.books.books);
 

  console.log("Redux books:", books); 

  const filteredBooks = Array.isArray(books)
    ? category
      ? books.filter((book) => book.category === category)
      : books
    : [];

  return (
    <div className="browse-container">
      <h1 className="browse-title">{category ? `${category} Books` : 'All Books'}</h1>
      {filteredBooks.length === 0 ? (
        <p>No books found in this category.</p>
      ) : (
        <ul className="book-list">
          {filteredBooks.map((book) => (
            <li key={book.id} className="book-item">
              <strong>{book.title}</strong> by {book.author}{' '}
			    <p><strong>Category:</strong> {book.category}</p>
              <Link to={`/book/${book.id}`} className="view-details-btn">
                View Details
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
