import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './HomePage.css';

export default function HomePage() {
  const books = useSelector((state) => state.books.books);

  
  const popularBooks = books.slice(0, 4);

  return (
    <div className="home-container">
      <h1 className="home-title">Welcome to the Online Library</h1>

      <div className="home-sections">
        <div className="home-section">
          <h2>Categories</h2>
          <ul className="category-list">
            <li><Link to="/books/Fiction">Fiction</Link></li>
            <li><Link to="/books/Non-Fiction">Non-Fiction</Link></li>
            <li><Link to="/books/Biography">Biography</Link></li>
          </ul>
        </div>

        <div className="home-section">
          <h2>Popular Books</h2>
          <ul className="popular-list">
            {popularBooks.map(book => (
              <li key={book.id}>
                <strong>{book.title}</strong> by {book.author}{' '}
                <Link to={`/book/${book.id}`}>View Details</Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
