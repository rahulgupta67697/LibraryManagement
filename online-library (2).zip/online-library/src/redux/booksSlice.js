import { createSlice } from '@reduxjs/toolkit';

const initialState = {
books: [
{
id: 1,
title: '1984',
author: 'George Orwell',
description: 'Dystopian novel.',
rating: '4.5',
category: 'Fiction'
},
{
id: 4,
title: '19847',
author: 'George Orwell',
description: 'Dystopian novel.',
rating: '4.5',
category: 'Fiction'
},
{
id: 2,
title: 'The Selfish Gene',
author: 'Richard Dawkins',
description: 'Science book.',
rating: '4.2',
category: 'Non-Fiction'
},
{
id: 3,
title: 'Steve Jobs',
author: 'Walter Isaacson',
description: 'Biography of Steve Jobs.',
rating: '4.7',
category: 'Biography'
}
]
};

const booksSlice = createSlice({
name: 'books',
initialState,
reducers: {
addBook: (state, action) => {
state.books.push(action.payload);
}
}
});

export const { addBook } = booksSlice.actions;
export default booksSlice.reducer;