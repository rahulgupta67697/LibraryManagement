#Online Library System

This is a modern Online Library System built with React, Redux Toolkit, and Vite. It allows users to browse books by category, add new books, view book details, and navigate through a clean user interface.

Features

-  View books categorized by Fiction, Non-Fiction, and Biography
-  Search and filter books
-  Add new books dynamically
-  View detailed information about each book
-  Client-side routing using React Router
-  State management using Redux Toolkit
-  Clean and responsive UI with CSS

## ️ Technologies Used

- React
- Redux Toolkit
- React Router DOM
- Vite (for development build)
- CSS (modular & responsive)

## Project Structure
online-library/
├── public/
├── src/
│ ├── components/ # Navbar, BookCard etc.
│ ├── pages/ # HomePage, BrowseBooks, AddBook, BookDetails, NotFound
│ ├── redux/ # Redux store and booksSlice
│ ├── App.jsx
│ ├── main.jsx
│ ├── index.css
│ └── ...
└── package.json

npm install
npm run dev


